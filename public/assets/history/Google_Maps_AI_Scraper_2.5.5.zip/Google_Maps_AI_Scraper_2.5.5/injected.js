// (function () {
//     var XHR = XMLHttpRequest.prototype;

//     var open = XHR.open;
//     var send = XHR.send;
//     var setRequestHeader = XHR.setRequestHeader;

//     XHR.open = function (method, url) {
//         this._method = method;
//         this._url = url;
//         this._requestHeaders = {};
//         this._startTime = (new Date()).toISOString();
//         this._previous = Date.parse(Date().toString())

//         return open.apply(this, arguments);
//     };

//     XHR.setRequestHeader = function (header, value) {

//         this._requestHeaders[header] = value;
//         return setRequestHeader.apply(this, arguments);
//     };

//     XHR.send = function (postData) {

//         this.addEventListener('load', function () {

//             var Url = this._url ? this._url.toLowerCase() : this._url;

//             if (Url && Url.match('/search?') !== null) {
//                 if (postData) {
//                     if (typeof postData === 'string') {
//                         try {
//                             // here you get the REQUEST HEADERS, in JSON format, so you can also use JSON.parse
//                             this._requestHeaders = postData;
//                         } catch (err) {
//                             console.log(err);
//                         }
//                     } else if (typeof postData === 'object' || typeof postData === 'array' || typeof postData === 'number' || typeof postData === 'boolean') {
//                         // do something if you need
//                     }
//                 }


//                 if (this.responseType != 'blob' && this.responseText) {

//                     try {
//                         var res = this.responseText;

//                         this._previous = Date.parse(Date().toString())

//                         res = res.replace('/*""*/', '');
//                         res = JSON.parse(res);
//                         var data = res.d;
//                         data = JSON.parse(data.replace(")]}'\n", ""));
//                         var data_arr = data[0][1];
//                         data = data_arr.filter(item => {
//                             if (item[14] !== undefined) {
//                                 return item
//                             }
//                         })
//                         const gmap_data = localStorage.getItem('gmap-data');
//                         if (gmap_data === null) {
//                             data = JSON.stringify(data);
//                             localStorage.setItem('gmap-data', data);
//                         } else {
//                             const _gmapdata = JSON.parse(gmap_data);
//                             _gmapdata.push(...data);

//                             const gdata = JSON.stringify(_gmapdata)
//                             localStorage.setItem('gmap-data', gdata);
//                         }

//                     } catch (err) {
//                         console.log("Error in responseType try catch:", this.responseType, err);
//                     }
//                 }
//             }
//         });

//         return send.apply(this, arguments);
//     };

// })(XMLHttpRequest);